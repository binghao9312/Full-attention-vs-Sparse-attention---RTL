source syn.tcl
